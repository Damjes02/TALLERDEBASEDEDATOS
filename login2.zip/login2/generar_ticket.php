<?php
require 'fpdf/fpdf.php'; // Asegúrate de ajustar la ruta si es necesario
require 'conexion.php'; // Asegúrate de ajustar la ruta si es necesario

session_start();

// Verificar sesión
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

$nombreUsuario = $_SESSION["username"] ?? "";

// Configuración de la conexión a la base de datos (reemplaza con tus propios datos)
$servername = "localhost";
$username = "root";
$password = "";
$database = "login_system";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Error de conexión a la base de datos: " . $conn->connect_error);
}

// Obtener detalles de compra para el ticket si se pasa la fecha de compra por GET
if (isset($_GET['fecha_compra'])) {
    $fechaCompra = $_GET['fecha_compra'];

    // Consulta para obtener detalles de la compra
    $queryDetalle = $conn->prepare("SELECT producto, cantidad, precio, (cantidad * precio) AS subtotal FROM compras WHERE usuario = ? AND fecha = ?");
    $queryDetalle->bind_param("ss", $nombreUsuario, $fechaCompra);
    $queryDetalle->execute();
    $resultDetalle = $queryDetalle->get_result();

    // Inicializar FPDF con tamaño personalizado para simular un ticket
    class PDF extends FPDF
    {
        function __construct()
        {
            parent::__construct('P', 'mm', array(80, 150)); // Ancho, Alto en milímetros
        }

        function Header()
        {
           

            // Título y otros encabezados
            $this->SetFont('Arial', 'B', 12);
            $this->Cell(0, 10, 'Tienda TodoEnUno Shop', 0, 1, 'C');
            $this->SetFont('Arial', '', 10);
            $this->Cell(0, 8, 'Agradecemos su preferencia', 0, 1, 'C');
            $this->Cell(0, 8, 'Ticket de Compra', 0, 1, 'C');
            // Línea divisoria
            $this->SetLineWidth(0.5);
            $this->Line(10, 38, 70, 38); // X1, Y1, X2, Y2
        }
    }

    $pdf = new PDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', '', 8);

    // Información del cliente y fecha de compra
    $pdf->Cell(0, 9, 'Cliente: ' . $nombreUsuario, 0, 1);
    $pdf->Cell(0, 6, 'Fecha: ' . $fechaCompra, 0, 1);
    $pdf->Ln(2);

    // Detalles de la compra
    while ($row = $resultDetalle->fetch_assoc()) {
        $pdf->MultiCell(0, 4, $row['cantidad'] . ' x ' . $row['producto'] . '    $' . number_format($row['subtotal'], 2), 0, 'L');
    }

    // Total de la compra
    $queryTotal = $conn->prepare("SELECT SUM(precio * cantidad) as total FROM compras WHERE usuario = ? AND fecha = ?");
    $queryTotal->bind_param("ss", $nombreUsuario, $fechaCompra);
    $queryTotal->execute();
    $resultTotal = $queryTotal->get_result();
    $total = $resultTotal->fetch_assoc()['total'];

    $pdf->SetFont('Arial', 'B', 9);
    $pdf->Cell(0, 6, 'Total: $' . number_format($total, 2), 0, 1, 'R');

    // Agradecimiento final
    $pdf->Ln(4);
    $pdf->MultiCell(0, 4, 'Gracias por su compra en TodoEnUno Shop. Esperamos verle nuevamente pronto.', 0, 'C');

    // Salida del PDF
    $pdf->Output('I', 'ticket_' . $fechaCompra . '.pdf');
}
?>
