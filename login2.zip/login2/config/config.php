<?php
define('CLIENT_ID', '');
define('LOCALE', 'es_ES');
?>