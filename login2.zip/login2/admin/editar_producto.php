<?php
require_once "../config/conexion.php";

// Verificar si se ha enviado el formulario para guardar cambios
if (!empty($_POST["btnGuardar"])) {
    if (!empty($_POST["id"]) && !empty($_POST["nombre"]) && !empty($_POST["descripcion"]) && !empty($_POST["caracteristicas"]) && !empty($_POST["p_normal"]) && !empty($_POST["p_rebajado"]) && !empty($_POST["cantidad"]) && !empty($_POST["categoria"])) {
        $id = $_POST["id"];
        $nombre = $_POST["nombre"];
        $descripcion = $_POST["descripcion"];
        $caracteristicas = $_POST["caracteristicas"];
        $p_normal = $_POST["p_normal"];
        $p_rebajado = $_POST["p_rebajado"];
        $cantidad = $_POST["cantidad"];
        $categoria = $_POST["categoria"];

        // Actualizar el producto en la base de datos
        $sql = "UPDATE productos SET nombre = '$nombre', descripcion = '$descripcion', caracteristicas = '$caracteristicas', precio_normal = '$p_normal', precio_rebajado = '$p_rebajado', cantidad = '$cantidad', id_categoria = '$categoria' WHERE id = $id";

        if ($conexion->query($sql) === TRUE) {
            echo '<div class="alert alert-success">Producto actualizado correctamente</div>';
        } else {
            echo '<div class="alert alert-danger">Error al actualizar el producto: ' . $conexion->error . '</div>';
        }
    } else {
        echo '<div class="alert alert-warning">Debes llenar todo el formulario</div>';
    }
}

// Verificar si se recibió un ID válido a través de la URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM productos WHERE id = $id";
    $result = $conexion->query($sql);

    if ($result->num_rows > 0) {
        $fila = $result->fetch_assoc();
        include("includes/header.php");
        ?>
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Editar Producto</title>
            <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body>
            <div class="container mt-5">
                <div class="text-center my-4">
                    <h3>Editar producto #<?= $id ?></h3>
                </div>
                <form method="post" action="">
                    <input hidden type="number" name="id" value="<?= $fila['id'] ?>">
                    <div class="mb-3">
                        <label class="form-label" for="nombre">Nombre</label>
                        <input type="text" class="form-control" name="nombre" value="<?= $fila['nombre'] ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="descripcion">Descripción</label>
                        <textarea class="form-control" name="descripcion" required><?= $fila['descripcion'] ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="caracteristicas">Características</label>
                        <textarea class="form-control" name="caracteristicas" required><?= $fila['caracteristicas'] ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="p_normal">Precio Normal</label>
                        <input type="number" step="0.01" class="form-control" name="p_normal" value="<?= $fila['precio_normal'] ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="p_rebajado">Precio Rebajado</label>
                        <input type="number" step="0.01" class="form-control" name="p_rebajado" value="<?= $fila['precio_rebajado'] ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="cantidad">Cantidad</label>
                        <input type="number" step="1" class="form-control" name="cantidad" value="<?= $fila['cantidad'] ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="categoria">Categoría</label>
                        <select class="form-control" name="categoria" required>
                            <?php
                            $categorias = mysqli_query($conexion, "SELECT * FROM categorias");
                            foreach ($categorias as $cat) { ?>
                                <option value="<?= $cat['id'] ?>" <?= ($cat['id'] == $fila['id_categoria']) ? 'selected' : '' ?>><?= $cat['categoria'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="text-center">
                        <input class="btn btn-primary" type="submit" value="Guardar" name="btnGuardar">
                        <a class="btn btn-success" href="productos.php"><i class="fas fa-arrow-left"></i> Regresar</a>
                    </div>
                </form>
            </div>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
        </body>
        </html>
        <?php
    } else {
        echo "No se encontró el producto con el ID proporcionado.";
    }
    include("includes/footer.php");
    exit();
}

include("includes/header.php");
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-8">
            <h1 class="text-dark mb-4">Productos</h1>
        </div>
        <div class="col-md-4 text-right">
            <button class="btn btn-primary" data-toggle="modal" data-target="#productosModal"><i class="fas fa-plus mr-2"></i>Nuevo</button>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>Imagen</th>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Características</th>
                            <th>Precio Normal</th>
                            <th>Precio Rebajado</th>
                            <th>Cantidad</th>
                            <th>Categoría</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = mysqli_query($conexion, "SELECT p.*, c.id AS id_cat, c.categoria FROM productos p INNER JOIN categorias c ON c.id = p.id_categoria ORDER BY p.id DESC");
                        while ($data = mysqli_fetch_assoc($query)) { ?>
                            <tr>
                                <td><img class="img-thumbnail" src="../assets/img/<?php echo $data['imagen']; ?>" width="50"></td>
                                <td><?php echo $data['nombre']; ?></td>
                                <td><?php echo $data['descripcion']; ?></td>
                                <td><?php echo $data['caracteristicas']; ?></td>
                                <td><?php echo $data['precio_normal']; ?></td>
                                <td><?php echo $data['precio_rebajado']; ?></td>
                                <td><?php echo $data['cantidad']; ?></td>
                                <td><?php echo $data['categoria']; ?></td>
                                <td>
                                    <a href="index.php?id=<?php echo $data['id']; ?>" class="btn btn-warning">
                                        <i class="fas fa-edit"></i> Editar
                                    </a>
                                    <form method="post" action="eliminar.php?accion=pro&id=<?php echo $data['id']; ?>" class="d-inline eliminar">
                                        <button class="btn btn-danger" type="submit">
                                            <i class="fas fa-trash-alt"></i> Eliminar
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="productosModal" tabindex="-1" role="dialog" aria-labelledby="productosModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="productosModalLabel">Nuevo Producto</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="" method="POST" enctype="multipart/form-data" autocomplete="off">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="nombre">Nombre</label>
                                <input id="nombre" class="form-control" type="text" name="nombre" placeholder="Nombre" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="cantidad">Cantidad</label>
                                <input id="cantidad" class="form-control" type="text" name="cantidad" placeholder="Cantidad" required>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="descripcion">Descripción</label>
                                <textarea id="descripcion" class="form-control" name="descripcion" placeholder="Descripción" rows="3" required></textarea>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="caracteristicas">Características</label>
                                <textarea id="caracteristicas" class="form-control" name="caracteristicas" placeholder="Características" rows="3"></textarea>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="p_normal">Precio Normal</label>
                                <input id="p_normal" class="form-control" type="text" name="p_normal" placeholder="Precio Normal" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="p_rebajado">Precio Rebajado</label>
                                <input id="p_rebajado" class="form-control" type="text" name="p_rebajado" placeholder="Precio Rebajado" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="categoria">Categoría</label>
                                <select id="categoria" class="form-control" name="categoria" required>
                                    <?php
                                    $categorias = mysqli_query($conexion, "SELECT * FROM categorias");
                                    foreach ($categorias as $cat) { ?>
                                        <option value="<?php echo $cat['id']; ?>"><?php echo $cat['categoria']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="foto">Foto</label>
                                <input type="file" class="form-control" name="foto" required>
                            </div>
                        </div>
                    </div>
                    <button class="btn btn-primary" type="submit">Registrar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include("includes/footer.php"); ?>
