<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login_system";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

function obtenerVentasDiarias($conn) {
    $sql = "SELECT DATE(fecha) as fecha, SUM(precio * cantidad) as total_dia FROM compras GROUP BY DATE(fecha)";
    $result = $conn->query($sql);

    if ($result === false) {
        throw new Exception("Error al ejecutar la consulta de ventas diarias: " . $conn->error);
    }

    $ventas_diarias = array();
    while ($row = $result->fetch_assoc()) {
        $ventas_diarias[$row['fecha']] = $row['total_dia'];
    }
    return $ventas_diarias;
}

function obtenerComprasDiarias($conn) {
    $sql = "SELECT DATE(fecha) as fecha, COUNT(*) as total_compras FROM compras GROUP BY DATE(fecha)";
    $result = $conn->query($sql);

    if ($result === false) {
        throw new Exception("Error al ejecutar la consulta de compras diarias: " . $conn->error);
    }

    $compras_diarias = array();
    while ($row = $result->fetch_assoc()) {
        $compras_diarias[$row['fecha']] = $row['total_compras'];
    }
    return $compras_diarias;
}

function obtenerTotalUsuarios($conn) {
    $sql = "SELECT COUNT(*) as total_usuarios FROM users";
    $result = $conn->query($sql);

    if ($result === false) {
        throw new Exception("Error al ejecutar la consulta de usuarios: " . $conn->error);
    }
    return $result->fetch_assoc()['total_usuarios'];
}

function obtenerProductosMasVendidos($conn) {
    $sql = "SELECT producto, COUNT(*) AS cantidad FROM compras GROUP BY producto ORDER BY cantidad DESC LIMIT 6";
    $result = $conn->query($sql);

    if ($result === false) {
        throw new Exception("Error al ejecutar la consulta de productos más vendidos: " . $conn->error);
    }

    $mas_vendidos = array();
    while ($row = $result->fetch_assoc()) {
        $mas_vendidos[] = $row;
    }
    return $mas_vendidos;
}

function obtenerTotalCategorias($conn) {
    $sql = "SELECT COUNT(*) as total_categorias FROM categorias";
    $result = $conn->query($sql);

    if ($result === false) {
        throw new Exception("Error al ejecutar la consulta de categorías: " . $conn->error);
    }
    return $result->fetch_assoc()['total_categorias'];
}

function obtenerVentasSemana($conn) {
    $sql = "SELECT SUM(precio * cantidad) as total_semana FROM compras WHERE WEEK(fecha) = WEEK(NOW())";
    $result = $conn->query($sql);

    if ($result === false) {
        throw new Exception("Error al ejecutar la consulta de ventas de la semana: " . $conn->error);
    }

    $ventas_semana = $result->fetch_assoc()['total_semana'];
    return $ventas_semana === null ? 0 : $ventas_semana; // Manejar caso donde no hay ventas esta semana
}

function obtenerTotalProductos($conn) {
    $sql = "SELECT COUNT(*) as total_productos FROM productos";
    $result = $conn->query($sql);

    if ($result === false) {
        throw new Exception("Error al ejecutar la consulta de productos: " . $conn->error);
    }
    return $result->fetch_assoc()['total_productos'];
}

function obtenerVentasSemanaPorDia($conn) {
    $sql = "SELECT DAYNAME(fecha) as dia_semana, SUM(precio * cantidad) as total_dia FROM compras WHERE WEEK(fecha) = WEEK(NOW()) GROUP BY DAYNAME(fecha)";
    $result = $conn->query($sql);

    if ($result === false) {
        throw new Exception("Error al ejecutar la consulta de ventas por día de la semana: " . $conn->error);
    }

    $ventas_diarias_semana = array_fill_keys(['Monay', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'], 0);

    while ($row = $result->fetch_assoc()) {
        $ventas_diarias_semana[$row['dia_semana']] = $row['total_dia'];
    }
    return $ventas_diarias_semana;
}

try {
    $ventas_diarias = obtenerVentasDiarias($conn);
    $compras_diarias = obtenerComprasDiarias($conn);
    $usuarios_total = obtenerTotalUsuarios($conn);
    $mas_vendidos = obtenerProductosMasVendidos($conn);
    $categorias_total = obtenerTotalCategorias($conn);
    $ventas_semana = obtenerVentasSemana($conn);
    $productos_total = obtenerTotalProductos($conn);
    $ventas_diarias_semana = obtenerVentasSemanaPorDia($conn);
} catch (Exception $e) {
    die('Error: ' . $e->getMessage());
}

// Cerrar conexión
$conn->close();
?>


<?php include("includes/header.php"); ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-size: 0.7rem;
        }
        .card-body {
            padding: 1rem; /* Aumentar el padding para dar más espacio a la gráfica */
        }
        .card-title {
            font-size: 0.9rem;
        }
        h2 {
            font-size: 1.3rem;
        }
        .container {
            max-width: 100%;
            margin: 0 auto;
            padding: 0.8rem;
        }
        .card {
            margin: 0.3rem 0;
        }
        canvas {
            max-width: 100%;
            margin: 0 auto;
            display: block; /* Asegurar que el canvas se comporte como un bloque */
            background-color: #ffffff; /* Color de fondo del área de la gráfica */
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1); /* Sombra ligera */
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Resumen de métricas -->
        <div class="row my-2">
            <div class="col-lg-3 col-md-6 mb-2">
                <div class="card bg-info text-white h-100">
                    <div class="card-body">
                        <div class="card-title">Usuarios</div>
                        <h2><?php echo $usuarios_total; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-2">
                <div class="card bg-primary text-white h-100">
                    <div class="card-body">
                        <div class="card-title">Categorías</div>
                        <h2><?php echo $categorias_total; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-2">
                <div class="card bg-secondary text-white h-100">
                    <div class="card-body">
                        <div class="card-title">Ventas de la Semana</div>
                        <h2>$<?php echo number_format($ventas_semana, 2); ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-2">
                <div class="card bg-secondary text-white h-100">
                    <div class="card-body">
                        <div class="card-title">Productos</div>
                        <h2><?php echo $productos_total; ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- Gráficos -->
        <div class="row my-2">
            <div class="col-lg-6 col-md-6 mb-2">
                <div class="card bg-light">
                    <div class="card-header bg-info text-white">Ventas por Día de la Semana</div>
                    <div class="card-body">
                        <canvas id="ventasSemanaChart"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 mb-2">
                <div class="card bg-light">
                    <div class="card-header bg-success text-white">Compras por Día</div>
                    <div class="card-body">
                        <canvas id="comprasPorDiaChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="row my-2">
            <div class="col-md-6 mb-2">
                <div class="card bg-light">
                    <div class="card-header bg-secondary text-white">Ventas del Día</div>
                    <div class="card-body">
                        <canvas id="ventasChart"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-2">
                <div class="card bg-light">
                    <div class="card-header bg-primary text-white">Productos Más Vendidos</div>
                    <div class="card-body">
                        <canvas id="productosMasVendidosChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

    </div>

<script>
    // Datos PHP a JavaScript
    var ventas_diarias = <?php echo json_encode(array_values($ventas_diarias)); ?>;
    var compras_diarias = <?php echo json_encode(array_values($compras_diarias)); ?>;
    var mas_vendidos = <?php echo json_encode($mas_vendidos); ?>;
    var ventas_diarias_semana = <?php echo json_encode($ventas_diarias_semana); ?>;

    // Paleta de colores personalizada para los gráficos
    var colores = ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'];

    // Configurar gráficos cuando el documento esté listo
    document.addEventListener('DOMContentLoaded', function() {
        // Gráfico de compras por día
        var ctxComprasPorDia = document.getElementById('comprasPorDiaChart').getContext('2d');
        new Chart(ctxComprasPorDia, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_keys($compras_diarias)); ?>,
                datasets: [{
                    label: 'Compras por Día',
                    data: compras_diarias,
                    backgroundColor: colores[0], // Usar el primer color de la paleta
                    borderColor: colores[0],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Gráfico de ventas por día de la semana
        var ctxVentasSemana = document.getElementById('ventasSemanaChart').getContext('2d');
        new Chart(ctxVentasSemana, {
            type: 'bar',
            data: {
                labels: Object.keys(ventas_diarias_semana),
                datasets: [{
                    label: 'Ventas',
                    data: Object.values(ventas_diarias_semana),
                    backgroundColor: colores[1], // Usar el segundo color de la paleta
                    borderColor: colores[1],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Gráfico de ventas del día
        var ctxVentas = document.getElementById('ventasChart').getContext('2d');
        new Chart(ctxVentas, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_keys($ventas_diarias)); ?>,
                datasets: [{
                    label: 'Ventas del Día',
                    data: ventas_diarias,
                    backgroundColor: colores[2], // Usar el tercer color de la paleta
                    borderColor: colores[2],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Gráfico de productos más vendidos (gráfico de pastel)
        var nombres_productos = mas_vendidos.map(function(item) {
            return item.producto;
        });

        var cantidades_vendidas = mas_vendidos.map(function(item) {
            return item.cantidad;
        });

        var ctxMasVendidos = document.getElementById('productosMasVendidosChart').getContext('2d');
        new Chart(ctxMasVendidos, {
            type: 'pie',
            data: {
                labels: nombres_productos,
                datasets: [{
                    label: 'Cantidad Vendida',
                    data: cantidades_vendidas,
                    backgroundColor: colores.slice(0, nombres_productos.length), // Usar colores definidos por los productos
                    borderColor: 'rgba(255, 255, 255, 0.6)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(tooltipItem) {
                                return `${tooltipItem.label}: ${tooltipItem.raw}`;
                            }
                        }
                    }
                }
            }
        });
    });
</script>
</body>
</html>

<?php include("includes/footer.php"); ?>



