<?php
session_start();

// Configuración de la conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$database = "login_system";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Error de conexión a la base de datos: " . $conn->connect_error);
}

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

$nombreUsuario = $_SESSION["username"] ?? "";

// Obtener detalles de compra para el modal
if (isset($_GET['detalle_compras_dia'])) {
    $fechaDetalle = $_GET['detalle_compras_dia'];
    $queryDetalle = $conn->prepare("SELECT producto, cantidad, precio, (cantidad * precio) AS subtotal FROM compras WHERE usuario = ? AND fecha = ?");
    $queryDetalle->bind_param("ss", $nombreUsuario, $fechaDetalle);
    $queryDetalle->execute();
    $resultDetalle = $queryDetalle->get_result();

    $detalles = [];
    while ($row = $resultDetalle->fetch_assoc()) {
        $detalles[] = $row;
    }

    echo json_encode(['fecha' => $fechaDetalle, 'detalles' => $detalles]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial de Compras</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Historial de Compras</h2>
        <table id="comprasTable" class="display">
            <thead>
                <tr>
                    <th>Fecha de Compra</th>
                    <th>Total</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = $conn->prepare("SELECT fecha, SUM(precio * cantidad) as total FROM compras WHERE usuario = ? GROUP BY fecha");
                $query->bind_param("s", $nombreUsuario);
                $query->execute();
                $result = $query->get_result();

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>{$row['fecha']}</td>
                        <td>\${$row['total']}</td>
                        <td>
                            <button class='btn btn-secondary' onclick='verDetalles(\"{$row['fecha']}\")'>
                                <i class='fas fa-eye'></i> Ver detalles
                            </button>
                            <a class='btn btn-warning' href='generar_ticket.php?fecha_compra={$row['fecha']}' target='_blank'>
                                <i class='fas fa-print'></i> Generar Ticket
                            </a>
                            <button class='btn btn-danger' onclick='eliminarFila(this)'>
                                <i class='fas fa-trash-alt'></i> Eliminar
                            </button>
                        </td>
                    </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <div class="container text-center mt-4">
        <a href="index.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Volver a la tienda</a>
    </div>

    <!-- Modal para detalles de compra -->
    <div class="modal fade" id="detallesModal" tabindex="-1" role="dialog" aria-labelledby="detallesModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="detallesModalLabel">Detalles de compra</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h6 id="fechaCompra"></h6>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Producto</th>
                                <th>Precio</th>
                                <th>Cantidad</th>
                                <th>SubTotal</th>
                            </tr>
                        </thead>
                        <tbody id="detallesCompra"></tbody>
                        <tfoot>
                            <tr>
                                <th colspan="3" class="text-right">Total</th>
                                <th id="totalCompra"></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#comprasTable').DataTable({
                "language": {
                    "lengthMenu": "Mostrar _MENU_ entradas",
                    "zeroRecords": "No se encontraron registros coincidentes",
                    "info": "Mostrando _START_ a _END_ de _TOTAL_ entradas",
                    "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                    "infoFiltered": "(filtrado de _MAX_ entradas totales)",
                    "search": "Buscar:",
                    "paginate": {
                        "first": "Primero",
                        "last": "Último",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    }
                }
            });
        });

        function verDetalles(fecha) {
            $.get('mis_compras.php?detalle_compras_dia=' + fecha, function(data) {
                var result = JSON.parse(data);
                var detallesHTML = '';
                var total = 0;

                result.detalles.forEach(function(detalle) {
                    detallesHTML += `<tr>
                        <td>${detalle.producto}</td>
                        <td>\$${detalle.precio}</td>
                        <td>${detalle.cantidad}</td>
                        <td>\$${detalle.subtotal}</td>
                    </tr>`;
                    total += parseFloat(detalle.subtotal);
                });

                $('#detallesCompra').html(detallesHTML);
                $('#fechaCompra').text('Fecha: ' + result.fecha);
                $('#totalCompra').text('\$' + total.toFixed(2));
                $('#detallesModal').modal('show');
            });
        }

        function eliminarFila(button) {
            var row = $(button).closest('tr');
            row.remove();
        }
    </script>
</body>
</html>
