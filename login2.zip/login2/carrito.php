<?php
session_start();
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION["username"]) && !empty($_SESSION["username"])) {
    $carrito = json_decode($_POST['carrito'], true);
    $username = $_SESSION["username"];

    // Insertar la compra en la base de datos
    $sql = "INSERT INTO compras (usuario, producto, cantidad, precio, fecha) VALUES (?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);

    foreach ($carrito as $producto) {
        $producto_id = $producto['id'];
        $cantidad = $producto['cantidad'];
        $precio_unitario = $producto['precio'];

        // Obtener el nombre del producto
        $producto_query = mysqli_query($conn, "SELECT nombre FROM productos WHERE id = $producto_id");
        $producto_data = mysqli_fetch_assoc($producto_query);
        $nombre_producto = $producto_data['nombre'];
        
        $stmt->bind_param("ssii", $username, $nombre_producto, $cantidad, $precio_unitario);
        $stmt->execute();
    }

    $stmt->close();
    $conn->close();

    // Limpiar el carrito después de realizar la compra
    $_SESSION['carrito'] = [];

    echo "Compra realizada correctamente.";
} else {
    echo "Error al procesar la compra. Asegúrate de haber iniciado sesión.";
}
?>
