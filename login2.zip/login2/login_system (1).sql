-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-11-2024 a las 23:30:07
-- Versión del servidor: 10.1.38-MariaDB
-- Versión de PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `login_system`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `categoria` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `categoria`) VALUES
(1, 'Tecnologia'),
(2, 'Bebidas'),
(3, 'Muebles'),
(4, 'Ropas'),
(12, 'Zapateria'),
(24, 'Productos de limpieza'),
(25, 'Lácteos'),
(26, 'Galletas'),
(27, 'Aceites'),
(28, 'Ofertas especiales');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras`
--

CREATE TABLE `compras` (
  `id` int(11) NOT NULL,
  `usuario` varchar(255) NOT NULL,
  `producto` varchar(255) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cantidad` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `compras`
--

INSERT INTO `compras` (`id`, `usuario`, `producto`, `precio`, `fecha`, `cantidad`) VALUES
(1, 'admin', 'PACK de productos de limpieza.', '850.00', '2024-06-16 20:21:07', 100),
(2, 'Deniss atilano cifuentes', 'Coca cola', '5.00', '2024-06-16 20:22:13', 3),
(3, 'Deniss atilano cifuentes', 'PACK de productos de limpieza.', '850.00', '2024-06-16 20:22:13', 10),
(4, 'Deniss atilano cifuentes', 'Despensa Familiar', '1200.00', '2024-06-16 20:22:13', 14),
(5, 'Deniss atilano cifuentes', 'Celular XiaomiPocox6 ', '7999.00', '2024-06-16 20:22:13', 1),
(6, 'Deniss atilano cifuentes', 'Coca Cola de lata ', '10.00', '2024-06-16 20:22:13', 1),
(7, 'Deniss atilano cifuentes', 'Cómoda', '400.00', '2024-06-16 20:22:13', 4),
(8, 'Deniss atilano cifuentes', 'PACK de refrescos ', '120.00', '2024-06-16 20:22:13', 1),
(9, 'Deniss atilano cifuentes', 'Zapato de piel color negro', '500.00', '2024-06-16 20:22:13', 1),
(10, 'Deniss atilano cifuentes', 'Conjunto de sudadera, pantalón y tenis', '645.00', '2024-06-16 20:22:13', 1),
(11, 'Deniss atilano cifuentes', 'messi con la copa del mundo', '30.00', '2024-06-16 20:22:13', 1),
(12, 'prueba', 'Coca Cola de lata ', '10.00', '2024-06-16 20:31:17', 1),
(13, 'prueba', 'CELULAR IPHONE 13 128 GB', '15000.00', '2024-06-16 20:31:52', 1),
(14, 'admin', 'PACK de productos de limpieza.', '850.00', '2024-06-16 20:38:13', 11),
(15, 'admin', 'Coca cola', '5.00', '2024-06-16 20:39:03', 1),
(16, 'admin', 'PACK de productos de limpieza.', '850.00', '2024-06-16 20:39:03', 1),
(17, 'admin', 'Despensa Familiar', '1200.00', '2024-06-16 20:39:03', 1),
(18, 'admin', 'Celular XiaomiPocox6 ', '7999.00', '2024-06-16 20:39:03', 1),
(19, 'admin', 'Coca Cola de lata ', '10.00', '2024-06-16 20:39:03', 1),
(20, 'admin', 'Cómoda', '400.00', '2024-06-16 20:39:03', 1),
(21, 'admin', 'PACK de refrescos ', '120.00', '2024-06-16 20:39:03', 1),
(22, 'admin', 'Zapato de piel color negro', '500.00', '2024-06-16 20:39:03', 1),
(23, 'admin', 'CELULAR IPHONE 13 128 GB', '15000.00', '2024-06-16 20:39:03', 2),
(24, 'admin', 'Celular XiaomiPocox6 ', '7999.00', '2024-06-16 20:43:29', 1),
(25, 'admin', 'Cómoda', '400.00', '2024-06-16 20:44:04', 1),
(26, 'admin', 'Cómoda', '400.00', '2024-06-16 20:44:11', 1),
(27, 'admin', 'Cómoda', '400.00', '2024-06-16 20:44:18', 1),
(28, 'prueba', 'Cómoda', '400.00', '2024-09-02 22:27:19', 1),
(29, 'prueba', 'Celular XiaomiPocox6 ', '7999.00', '2024-09-24 03:42:49', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensaje`
--

CREATE TABLE `mensaje` (
  `id` int(11) NOT NULL,
  `usuario_envia` varchar(100) NOT NULL,
  `mensaje` text NOT NULL,
  `fecha_envio` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `mensaje`
--

INSERT INTO `mensaje` (`id`, `usuario_envia`, `mensaje`, `fecha_envio`) VALUES
(6, 'Alan', 'HOLA, ME GUSTO MUCHO, TODO GRACIAS\r\n', '2024-06-04 02:49:16'),
(7, 'prueba', 'LE HACE FALTA MUCHAS COSAS A TU PAGINA', '2024-06-04 10:16:08'),
(8, 'chupapi', 'Hola quisiera que agregaron mas productos, gracias!!', '2024-06-07 00:05:38');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `descripcion` text NOT NULL,
  `precio_normal` decimal(10,2) NOT NULL,
  `precio_rebajado` decimal(10,2) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `imagen` varchar(50) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `caracteristicas` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `descripcion`, `precio_normal`, `precio_rebajado`, `cantidad`, `imagen`, `id_categoria`, `caracteristicas`) VALUES
(6, 'Coca cola', '1.5 ml', '5.00', '5.00', 15, '20211212082628.jpg', 2, NULL),
(20, 'PACK de productos de limpieza.', 'Detergente UNEX, Blanqueador UNEX, Líquido para lavar platos UNEX, Suavizante de telas UNEX, ESTO Y MAS!!!', '1000.00', '850.00', 50, '20240603235242.jpg', 28, NULL),
(21, 'Despensa Familiar', 'Cuenta con una enorme calidad de productos, corre por ellas que hay poca.!!', '1600.00', '1200.00', 20, '20240603235414.jpg', 28, NULL),
(22, 'Celular XiaomiPocox6 ', '256GB, 8 de ram, Snapdragon+ 8 Gen 1', '7999.00', '7999.00', 44, '20240604000052.jpg', 1, NULL),
(23, 'Zapato de piel color negro', 'Cómodos del numero #8', '550.00', '500.00', 3, '20240604000308.jpg', 12, NULL),
(24, 'PACK de refrescos ', 'Aprovecha y llévatelo de una vez!!', '120.00', '120.00', 55, '20240604000614.jpg', 2, NULL),
(27, 'Cómoda', 'De buen material, llévatelo ya!', '400.00', '400.00', 122, '20240604001013.jpg', 3, NULL),
(28, 'Coca Cola de lata ', 'Refrescante de 235Ml', '10.00', '10.00', 23, '20240604001140.jpg', 2, NULL),
(31, 'CELULAR IPHONE 13 128 GB', 'Iphone 13 color rosa, unico!!', '19000.00', '15000.00', 23, '20240604051610.jpg', 1, NULL),
(32, 'Mueble De Tv Arce', ' El hermoso acabado en madera es perfecto para cualquier decoración del hogar. Mantenga su sala de estar con un aspecto elegante con el Mueble De Tv Arce', '5799.00', '5799.00', 1222, '20240604052349.jpg', 3, NULL),
(33, 'Conjuntos de verano para hombre', 'estampado floral, playa, día festivo, casual, manga corta, con cierre, conjunto corto', '500.00', '470.00', 11, '20240604052616.jpg', 4, NULL),
(34, 'Conjunto de sudadera con pants ', 'Muy cómodo, color rojo!', '450.00', '450.00', 333, '20240604052745.jpg', 4, NULL),
(35, 'Conjunto de sudadera, pantalón y tenis', 'Pantalon talla 32, sudadera mediana, tenis del numero 7/5', '700.00', '645.00', 22, '20240604053103.jpg', 4, NULL),
(36, 'Tenis puma numero 7', 'Lo mejor que encontraras hoy, cómodos y económicos ', '500.00', '500.00', 44, '20240604055634.jpg', 12, NULL),
(37, 'Tenis Nike Jordan ultima edición ', 'Tenis cómodos de color negro, rojo y blanco, numero 8', '1900.00', '1900.00', 22, '20240604060352.jpg', 12, NULL),
(43, 'messi con la copa del mundo', 'el mejor de todos los tiempo', '33.00', '30.00', 33, '20240607051836.jpg', 28, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contraseña` varchar(255) NOT NULL,
  `estado` enum('pendiente','activo') DEFAULT 'pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`id`, `nombre`, `email`, `contraseña`, `estado`) VALUES
(6, 'Alan03', 'alanvegacv@gmail.com', '$2y$10$Ds35Q6DE3eKKm1Z7cQTPo.1IybzwnQj3U3irmV8dmf2/3ZTOzjJqK', 'pendiente'),
(10, 'Deniss atilano cifuentes', 'deni@gmail.com', '$2y$10$9ErQm/Yk8BEr8LEb4XrLK.IA34IyOIUkar1oGZXav0igy82GPxaK6', 'pendiente'),
(11, 'ALAN COLLADO VEGA', 'alancollado111@gmail.com', '$2y$10$FpOVHXlwx1YeItIuF1C4HuYVbS84qwxdbryObIstgyTF0ZOkRhIF2', 'activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respuestas`
--

CREATE TABLE `respuestas` (
  `id` int(11) NOT NULL,
  `mensaje_id` int(11) NOT NULL,
  `respuesta` text NOT NULL,
  `fecha_envio` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `respuestas`
--

INSERT INTO `respuestas` (`id`, `mensaje_id`, `respuesta`, `fecha_envio`) VALUES
(6, 6, 'Hola Alan, es un placer saber que te haya gustado todo, saludos.🤗🤗', '2024-06-03 18:50:11'),
(7, 7, 'GRACIAS POR COMUNICARTE CON NOSOSTROS, ESTAREMOS TRABAJANDO CON LO QUE NOS HACE FALTA SALUDOS :))', '2024-06-04 02:17:02'),
(8, 8, 'Nel', '2024-06-06 16:06:01');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` tinyint(1) DEFAULT '1',
  `last_login` datetime DEFAULT NULL,
  `last_logout` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `created_at`, `active`, `last_login`, `last_logout`, `last_activity`) VALUES
(1, 'chupapi', 'alanvegacv@gmail.com', '$2y$10$yL7Wgkt.XqcHqwYncYheZOx/LnAP64El7NqQVXUMinCTxy3Bu2nVi', '2024-06-02 19:43:36', 1, '2024-06-06 13:08:47', '2024-06-06 13:10:08', '2024-06-06 13:08:47'),
(9, 'Deniss atilano cifuentes', 'deni@gmail.com', '$2y$10$kuohbFH2oK3KKNoAxxs7ju0xpv/MrAt6Y0Fs70U2Fsvkpt6JwmjSG', '2024-06-06 00:03:53', 1, '2024-06-16 14:21:44', '2024-06-16 14:24:18', '2024-06-16 14:21:44'),
(14, 'admin', 'admin@gmail.com', '$2y$10$jc/GHkOMHNgFpoa4I1kQvu5VGQuP0rykdaVns8ThNUgCFXD.FacYy', '2024-06-05 01:37:04', 1, '2024-06-21 11:01:17', '2024-06-16 14:40:10', '2024-06-21 11:01:17'),
(16, 'prueba', 'prueba@gmail.com', '$2y$10$sfEcLHVEM8c9653kU28IOOMn.a7VFTXCzI2BS745HVDCCg1SQaqXC', '2024-09-02 22:26:57', 1, '2024-09-23 22:42:38', '2024-09-23 22:42:57', '2024-09-23 22:42:38');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `clave` varchar(100) NOT NULL,
  `last_logout` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `nombre`, `clave`, `last_logout`) VALUES
(1, 'admin', 'Alan', '21232f297a57a5a743894a0e4a801fc3', '2024-06-02 22:06:10');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `compras`
--
ALTER TABLE `compras`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mensaje`
--
ALTER TABLE `mensaje`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_categoria` (`id_categoria`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indices de la tabla `respuestas`
--
ALTER TABLE `respuestas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mensaje_id` (`mensaje_id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de la tabla `compras`
--
ALTER TABLE `compras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT de la tabla `mensaje`
--
ALTER TABLE `mensaje`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `respuestas`
--
ALTER TABLE `respuestas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `respuestas`
--
ALTER TABLE `respuestas`
  ADD CONSTRAINT `respuestas_ibfk_1` FOREIGN KEY (`mensaje_id`) REFERENCES `mensaje` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
